Start-Process "C:\Users\Velizman\Desktop\goodbye\turkey_dnsredir.cmd" -WindowStyle Hidden
